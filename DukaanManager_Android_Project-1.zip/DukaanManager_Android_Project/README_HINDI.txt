DUKAAN MANAGER - ANDROID APK PROJECT

Is ZIP mein aapki HTML app Android WebView app ke andar rakhi gayi hai.
APK banane ka asaan tareeqa (phone/tablet se GitHub):

1. github.com par login karein ya account banayein.
2. New repository banayein, naam DukaanManager rakhein.
3. Is ZIP ko extract karein aur iske andar ki files/folders repository mein upload karein. ZIP ko sirf upload karna kaafi nahi; pehle extract karein.
4. Repository mein Actions tab kholein.
5. 'Build Dukaan Manager APK' workflow choose karein aur 'Run workflow' dabayein.
6. Build complete hone par run ke neeche Artifacts mein 'Dukaan-Manager-APK' download karein.
7. ZIP artifact extract karein; app-debug.apk ko Android par tap karke install karein. Agar prompt aaye to browser/file manager ke liye 'Install unknown apps' allow karein.

NOTES:
- APK debug/test build hai; Play Store release ke liye signed release build alag se karna hoga.
- Data app ke WebView/local browser storage mein rahega. App uninstall ya app data clear karne se data mit sakta hai. Backup export ka istemal karein.
- OCR library internet se load hoti hai, isliye bill OCR ke liye internet chahiye.
- Camera/file upload functionality device/browser permission aur Android picker support par depend karti hai.
